

RDFS <- function(x,t,P,aerr) {

  dt = t[2]-t[1]
  N=length(x)
  Df=1/(N*dt)
  h = matrix(0,1,length(x))
  for (i in 1:length(x)){
    h[i]<-0.5-0.5*cos(2*pi*i/(length(x)-1))
  }

  X=fft(t(h)*x)/N
  X=as.matrix(t(X[1:N/2]))

  Df=1/(N*dt);
  Freq=c((1:((N/2)-1))*Df)

  xIndex = which.max(abs(X));
  Freqmax = Freq[xIndex];

  a = which( abs(X)>0, arr.ind=F);
  a = a[1]

  if (a==1){
    a = 1+1
  } else {
    a=a
  }

  Freq1 = Freq[a];

  T1 = 8*pi/Freqmax;
  Tm=T1;

  par(mfrow=c(1,1))
  plot(t,x,main="Signal Smoothing via  RDFS",xlab="Time",ylab="Signal",pch = 16,col="blue")

  ee = 100000;
  ee2 = 100000;
  e = 100000;

  num = 0;

  while (ee2>aerr) {

    T1 = rnorm(length(t),mean = Tm, sd = 40)


    for (l in 1:length(t)){

      W = matrix(0,length(t),P*2+1);

      for (n in 1:length(t)){
        for (k in 1:P)
          W[n,k]=exp(1i*2*pi*k*t[n]/T1[l]);
      }


    for (n in 1:length(t)){
      k=P+1
      W[n,k]=exp(-1i*2*pi*0*t[n]/T1[l]);
    }

    for (n in 1:length(t)){
      for (k in (P+2):(2*P+1)){
        W[n,k]=exp(-1i*2*pi*k*t[n]/T1[l]);
      }
    }
    }


    Xhat = solve(Conj(t(W))%*%W)%*%Conj(t(W))%*%(x);

    xhat = W%*%Xhat;

      e=sum((xhat-x))/length(x);

    if (abs(e)<abs(ee)){
      ee=abs(e);
      Tm = T1[l];
      ee2 = sum((abs(x)-abs(xhat)))/length(x);
    } else {
      ee=ee;
    }

    num = num+1;


    T1 = Tm;

  }

  xhat <- as.vector(Re(xhat))

  lines(t,Re(xhat), lwd = 2)

  legend("topright", legend=c("Noisy signal", "RDFS"),
         col=c("blue","black"),lwd = c(NA,2), lty=c(NA,1),pch=c(16,NA))

  dxhat = matrix(0,length(x))

  for (n in 1:length(x)){
  for (k in (-length(X)/2):(length(X)/2)){
  for (m in 1:length(X)){
  dxhat[n] =  (-1i*2*pi*k)/(T1)*(X[m])*exp((-1i*2*pi*k*t(n))/(T1))
  }
  }
  }

  dxhat <- as.vector(dxhat)

  return(list(xhat=xhat,fir_der=dxhat))

}





RDFS_2D <- function(x,t1,t2,P1,P2,aerr) {

  dt1 = t1[2]-t1[1]
  N1=length(t1)
  Df1=1/(N1*dt1)
  h1 = matrix(0,1,length(t1))
  for (i in 1:length(t1)){
    h1[i]<-0.5-0.5*cos(2*pi*i/(length(t1)-1))
  }

  X1=fft(t(h1)*x[,1])/N1
  X1=as.matrix(t(X1[1:N1/2]))

  Df1=1/(N1*dt1);
  Freq1=c(1:(N1/2-1))*Df1;

  xIndex1 = which.max(abs(X1));
  Freqmax1 = Freq1[xIndex1];

  a1 = which( abs(X1)>0, arr.ind=F);
  a1 = a1[1]

  if (a1==1){
    a1 = 1+1
  } else {
    a1=a1
  }

  Freq1 = Freq1[a1];

  T1 = 8*pi/Freqmax1;
  Tm1=T1;

  dt2 = t2[2]-t2[1]
  N2=length(t2)
  Df2=1/(N2*dt2)
  h2 = matrix(0,1,length(t2))
  for (i in 1:length(t2)){
    h2[i]<-0.5-0.5*cos(2*pi*i/(length(t2)-1))
  }

  X2=fft(t(h2)*x[1,])/N2
  X2=as.matrix(t(X2[1:N2/2]))

  Df2=1/(N2*dt2);
  Freq2=c(1:(N2/2-1))*Df2;

  xIndex2 = which.max(abs(X2));
  Freqmax2 = Freq2[xIndex2];

  a2 = which( abs(X2)>0, arr.ind=F);
  a2 = a2[1]

  if (a2==1){
    a2 = 1+1
  } else {
    a2=a2
  }

  Freq2 = Freq2[a2];

  T2 = 8*pi/Freqmax2;
  Tm2=T2;

  par(mfrow=c(1,2))

  persp(t1,t2,x, theta = 20, main="Noisy signal",xlab="t1",ylab="t2",zlab="Signal")

  ee = 100000;
  ee2 = 100000;
  e = 100000;

  num = 0;

  while (ee>aerr) {

    T1 = rnorm(length(t1),mean = Tm1, sd = 30)
    T2 = rnorm(length(t2),mean = Tm2, sd = 30)

    for (m in 1:length(t1)){

      W1 = matrix(0,length(t1),P1*2+1);

      for (n in 1:length(t1)){
        for (k in 1:P1)
          W1[n,k]=exp(1i*2*pi*k*t1[n]/T1[m]);
      }

      for (n in 1:length(t1)){
        k=P1+1
        W1[n,k]=exp(-1i*2*pi*0*t1[n]/T1[m]);
      }

      for (n in 1:length(t1)){
        for (k in (P1+2):(2*P1+1)){
          W1[n,k]=exp(-1i*2*pi*k*t1[n]/T1[m]);
        }
      }
    }

    for (m in 1:length(t2)){

      W2 = matrix(0,length(t2),P2*2+1);

      for (n in 1:length(t2)){
        for (k in 1:P2)
          W2[n,k]=exp(1i*2*pi*k*t2[n]/T2[m]);
      }


      for (n in 1:length(t2)){
        k=P2+1
        W2[n,k]=exp(-1i*2*pi*0*t2[n]/T2[m]);
      }

      for (n in 1:length(t2)){
        for (k in (P2+2):(2*P2+1)){
          W2[n,k]=exp(-1i*2*pi*k*t2[n]/T2[m]);
        }
      }
    }

    Xhat = solve(Conj(t(W1))%*%W1)%*%Conj(t(W1))%*%(x)%*%Conj((W2))%*%solve(Conj(t(W2))%*%W2);

    xhat = W1%*%Xhat%*%t(W2);


    e=sum((xhat-x))/length(x)

    if (abs(e)<abs(ee)){
      ee=abs(e);
      Tm1 = T1[m];
      Tm2 = T2[m]
      ee2 = sum((abs(x)-abs(xhat)))/length(x);
    } else {
      ee=ee;
    }

    num = num+1;


    T1 = Tm1
    T2 = Tm2

  }

  persp(t1,t2,Re(xhat), theta = 20, main="Signal smoothed by the RDFS",xlab="t1",ylab="t2",zlab="Signal")

  return(xhat)

}





DKL<-function(frf,t,P,Nobs,Nt){

  dt=t[2]-t[1];
  Df=1/(2*Nobs*dt);
  Freq=((1:Nobs)-1)*Df;

  Df = f[2]-f[1];

  X=frf;

  t = f;


  par(mfrow=c(1,2))

  plot(f,20*log10(abs(X[1,])), type='l', main="Noisy FRF",xlab="Freq. [Hz]",ylab="Signal [dB]",lwd=1)


  for (i in 2:nblk){
    lines(f, 20*log10(abs(frf[i,])))
  }

  ones = matrix(1,Nt,1);

  Mu = matrix(0,Nt,Nobs);
  Mu = as.matrix(Mu)

  for (i in 1:Nt){
    Mu[i,] = t(X)%*%ones/(Nt);
  }

  X0 = t(X)-t(Mu);

  C_hat = (1/(Nt))*X0%*%t(X0)*Df;
  C_hat = as.matrix(C_hat)

  eig = eigen(C_hat)

  V = as.matrix(eig$vectors)
  D = as.matrix(eig$values)

  Z = matrix(0,Nt,Nobs);

  for (i in 1:Nt){
    Z[i,] = (1/D[i]*t(X0[,i])*V[i,])
  }


  plot(t,(20*log10(abs(Mu[1,]))), main="Estimation of H",xlab="Freq. [Hz]",ylab="Signal [dB]",lwd=1, type= 'l');



  XKL = matrix(0,Nt,Nobs);


  XKL = Mu;
  for (i in 1:Nt){
    for (j in 1:Nobs){
      for (k in 1:P){
        XKL[i,j] = XKL[i,j] + sqrt(D[i])*t(V[j,k])*Z[k,j];
      }
    }
  }

  XKL_max = matrix(0,1,Nobs);
  XKL_min = matrix(0,1,Nobs);

  for (i in 1:Nobs){
    XKL_max[1,i] = max(abs(XKL[,i]));
    XKL_min[1,i] = min(abs(XKL[,i]));
  }


  par(mfrow=c(1,1))
  plot(t,20*log10(abs(XKL_min)),col = 'red',type='l', main="Signal inherent limits",xlab="Freq. [Hz]",ylab="Signal [dB]",lwd=1)
  lines(t,20*log10(abs(XKL_max)),col = 'blue',type='l')
  legend("bottomright", legend=c('X_{KL,max,sys}','X_{KL,min,sys}'),
         col=c("blue","black"),lwd = c(NA,2), lty=c(NA,1),pch=c(16,NA))


  es = sum((20*log10(abs(Mu[1,]))-20*log10(abs(XKL_max)))^2);
  es = es+sum((20*log10(abs(Mu[1,]))-20*log10(abs(XKL_min)))^2);
  es = sqrt(es)/(2*length(XKL_max))


  XKLt = matrix(0,Nt,Nobs);


  XKLt = Mu;
  for (i in 1:Nt){
    for (j in 1:Nobs){
      for (k in 1:Nt){
        XKLt[i,j] = XKLt[i,j] + sqrt(D[i])*t(V[j,k])*Z[k,j];
      }
    }
  }

  XKLt_max = matrix(0,1,Nobs);
  XKLt_min = matrix(0,1,Nobs);

  for (i in 1:Nobs){
    XKLt_max[1,i] = max(abs(XKLt[,i]));
    XKLt_min[1,i] = min(abs(XKLt[,i]));
  }


  et = sum((20*log10(abs(Mu[1,]))-20*log10(abs(XKLt_max)))^2);
  et = et+sum((20*log10(abs(Mu[1,]))-20*log10(abs(XKLt_max)))^2);
  et = sqrt(et)/(length(XKLt_max))

  en = et-es

  return(list(xhat=Mu[1,],xmax = XKL_max, xmin = XKL_min, es = es, en = en))

}


